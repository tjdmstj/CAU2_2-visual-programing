f=open("dict_test.txt","r")
list=[]

while True:
    w=f.readline()
    if w==" ":break
    ww=w.split(":")
    list.append(ww[0])
f.close()

point=0
firstword="apple"
print("%s 끝말 잇기?"%firstword)
    
    
for i in range(10):
    count=1
    word=input()
    if word+" " in list:
        if firstword[-1]==word[0]:
            if len(firstword)==len(word):
                for i in range(2,len(word)):
                    if firstword[-i:]==word[:-len(word)+i]:
                        count +=1
                    else:
                        
                        firstword=word
                        count= len(word)*count
                        point +=count
                        print("%d점. 총점 %d점"%(count,point))
                        break
            elif len(firstword)<len(word):
                for i in range(2,len(firstword)):
                    if firstword[-i:]==word[:-len(word)+i]:
                        count +=1
                    else:
                    
                        firstword=word
                        count= len(word)*count
                        point +=count
                        print("%d점. 총점 %d점"%(count,point))
                        break
            else:
                for i in range(2,len(word)):
                    if firstword[-i:]==word[:-len(word)+i]:
                        count +=1
                    else:
                    
                        firstword=word
                        count= len(word)*count
                        point +=count
                        print("%d점. 총점 %d점"%(count,point))
                        break
        elif firstword[-1]!=word[0]:
            if len(firstword)==len(word):
                for i in range(2,len(word)):
                    if firstword[-i:]==word[:-len(word)+i]:
                        count +=1
                    else:
                        if count>=2:
                            firstword=word
                            count= len(word)*count
                            point +=count
                            print("%d점. 총점 %d점"%(count,point))
                            break
                        else:
                            print("끝말이 이어지지 않습니다.")
                            break
            elif len(firstword)<len(word):
                for i in range(2,len(firstword)):
                    if firstword[-i:]==word[:-len(word)+i]:
                        count +=1
                    else:
                        if count>=2:
                            firstword=word
                            count= len(word)*count
                            point +=count
                            print("%d점. 총점 %d점"%(count,point))
                            break
                        else:
                            print("끝말이 이어지지 않습니다.")
                            break
            else:
                for i in range(2,len(word)):
                    if firstword[-i:]==word[:-len(word)+i]:
                        count +=1
                    else:
                        if count>=2:
                            firstword=word
                            count= len(word)*count
                            point +=count
                            print("%d점. 총점 %d점"%(count,point))
                            break
                        else:
                            print("끝말이 이어지지 않습니다.")
                            break
        print("%s 끝말 잇기?"%firstword)
    else:
        print("사전에 없는 단어입니다.")
        print("%s 끝말 잇기?"%firstword)
    
