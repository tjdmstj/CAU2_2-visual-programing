f=open("dict_test.txt","r")
while True:
    word=input("단어? ")
    f.seek(0)
    for i in range(51844):
        w=f.readline()
        wordlist=w.split(":")
        if wordlist[0]==(word+" "):
            print(wordlist[0][:-1],end=" ")
            print(wordlist[1][1:-1])
            break
f.close()
