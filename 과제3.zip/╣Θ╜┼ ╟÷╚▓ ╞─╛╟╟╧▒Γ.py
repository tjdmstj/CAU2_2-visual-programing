f = open("owid-covid-data.csv", "r", encoding='utf-8')
f.readline()
i = 1
j = 1
while True:
    w = f.readline()
    world = w.split(",")
    world = world[2]
    if world == "South Sudan":
        break
    i += 1

f.seek(0)
w = f.readline()
world = w.split(",")
print(world[2], "   ", world[3], "   ", "people fully vaccinated", "   ", "people only partly vaccinated")
while True:
    f.seek(0)
    for j in range(i - 1):
        w = f.readline()
    world = w.split(",")
    if (world[35] != " " and world[36] != " " and world[46] != " "):
        break
    else:
        i -= 1

print(world[2], " ", world[3], " ", world[36], " ", int((float(world[41]) - float(world[42]))*100)/100*float(world[46]))
f.close()
