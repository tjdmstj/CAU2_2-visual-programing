#1-3

print("noodle:500원, ham: 200원, egg:100원, spaghetti:900원")
menulist=["noodle","ham","egg","spaghetti"]
while True:
    print("안녕하세요 다음의 메뉴 중 원하는 메뉴를 선택하세요")
    menu=input("(noodle,ham,egg,spaghetti)")
    if (menu in menulist):
        if(menu=="noodle"):
            print("500원입니다.")
        if(menu=="ham"):
            print("200원입니다.")
        if(menu=="egg"):
            print("100원입니다.")
        if(menu=="spaghetti"):
            print("900원입니다.")
    else:
        print("그런 메뉴는 없습니다.")
