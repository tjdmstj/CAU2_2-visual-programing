#1-8
import math

for i in range(0,361,10):
    print(" "*(10+int(math.sin(math.radians(i))*10)),end='')
    print(" "*int(math.sin(math.radians(i))*10),end='')
    print("*")
