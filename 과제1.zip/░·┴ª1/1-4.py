#1-4

list=[]
while True:
    a=int(input("데이터를 입력하세요(입력을 마치려면 0을 입력하세요)"))
    if(a!=0):
        list.append(a)
    else:
        break
list.sort()
print("결과:",end=' ')
for i in list:
    print(i,end=' ')
print("(",len(list),"개)")
