#1-1

while True:
    a=int(input("숫자를 입력하세요"))
    if a>0 :
        print(a)
    elif a<0:
        print(a*(-1))
    else:
        break
            
