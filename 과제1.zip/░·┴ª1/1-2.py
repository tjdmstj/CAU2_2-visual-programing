#1-2

list=["흑석동","사당동","상도동","노량진동","규동"]
while True:
    a=input("동을 입력하세요.")
    if(a in list):
        print(list.index(a)+1,"번째 동입니다.")
    else:
        list.append(a)
        print("새로운 동명입니다.", len(list),"번째 동으로 등록합니다.")
        
