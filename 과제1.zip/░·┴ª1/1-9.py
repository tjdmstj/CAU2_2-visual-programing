#1-9

print("N<M은 각각 2에서 9사이의 숫자이고, N<=M이다.")
while True:
    N=int(input("N=?"))
    M=int(input("M=?"))
    blank=80/(2*(M-N)+1)
    for i in range(1,10):
        for j in range(N,M+1):
            print(' '*int(blank),end='')
            print("%d*%d=%2d"%(j,i,j*i),end='')
        print("")
 
        
        
    
        
    
        
