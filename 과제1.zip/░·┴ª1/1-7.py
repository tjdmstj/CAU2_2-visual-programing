#1-7

import random
cw=pw=cl=pl=0
rround=1
print("가위바위보게임")
while True:
    print(" ")
    print("컴퓨터",cw,"승",cl,"패",end=' ')
    print("당신",pw,"승",pl,"패")
    print("(라운드",rround,")")
    rround=rround+1
    com=random.randint(1,3)
    print("컴퓨터가 결정했습니다.")
    player=input("무엇을 내시겠습니까?(가위,바위,보)")
    if player=="가위":
        player=1
    elif player=="바위":
        player=2
    else:
        player=3

    if com==player:
        print("비겼습니다.")
        continue
    elif com<player:
        if com==1 and player==3:
            cw=cw+1
            pl=pl+1
            print("컴퓨터는 가위, 당신은 보, 컴퓨터가 이겼습니다.")
        else:
            cl=cl+1
            pw=pw+1
            if com==1 and player==2:
                print("컴퓨터는 가위, 당신은 바위, 당신이 이겼습니다.")
            else:
                print("컴퓨터는 바위, 당신은 보, 당신이 이겼습니다.")
    else:
        if com==3 and player==1:
            cl=cl+1
            pw=pw+1
            print("컴퓨터는 보, 당신은 가위, 당신이 이겼습니다.")
        else:
            cw=cw+1
            pl=pl+1
            if com==2 and player==1:
                print("컴퓨터는 바위, 당신은 가위, 컴퓨터가 이겼습니다.")
            else:
                print("컴퓨터는 보, 당신은 바위, 컴퓨터가 이겼습니다.")
    if cw==3 or pw==3:
        print("컴퓨터",cw,"승",cl,"패",end=' ')
        print("당신",pw,"승",pl,"패")
        break
    
    
