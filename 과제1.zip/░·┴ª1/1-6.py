#1-6

won=int(input("원금을 입력하세요(원)."))
per=int(input("금리를 입력하세요(%)."))
print("원금 ",won,"원 금리 ",per,"%입니다.")
year=1
print("기간"," ","합계")
for i in range(20):
    print(year,"년"," ",round(won*(1+per/100)**year,1))
    year=year+1
