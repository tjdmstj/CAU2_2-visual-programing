#2-5
num=[" "," ","이","삼","사","오","육","칠","팔","구"," "]
while True:
    number=int(input("숫자는?"))
    if number>99999:
        continue
    else:
        print(format(number,',d'))
    
    if number>10000:
        print("%c만"%num[number//10000],end=' ')
        if (number-number//10000*10000)<1000:
            print("",end=' ')
        else:
            print("%c천"%num[number//1000-number//10000*10],end=' ')
        
        if (number-number//1000*1000)<100:
            print("",end=' ')
        else:
            print("%c백"%num[number//100-number//1000*10],end=' ')
        if (number-number//100*100)<10:
            print("",end=' ')
        else:
            print("%c십"%num[number//10-number//100*10],end=' ')
        if (number-number//10*10)!=0:
            print("%c"%num[number-number//10*10])
        else:
            print(" ")
            
    elif number>1000:
        print("%c천"%num[number//1000],end=' ')
        if (number-number//1000*1000)<100:
            print("",end=' ')
        else:
            print("%c백"%num[number//100-number//1000*10],end=' ')
        if (number-number//100*100)<10:
            print("",end=' ')
        else:
            print("%c십"%num[number//10-number//100*10],end=' ')
        if (number-number//10*10)!=0:
            print("%c"%num[number-number//10*10])
        else:
            print(" ")
        
    elif number>100:
        print("%c백"%num[number//100],end=' ')
        if (number-number//100*100)<10:
            print("",end=' ')
        else:
            print("%c십"%num[number//10-number//100*10],end=' ')
        if (number-number//10*10)!=0:
            print("%c"%num[number-number//10*10])
        else:
            print(" ")
    elif number>10:
        print("%c십"%num[number//10],end=' ')
        if (number-number//10*10)!=0:
            print("%c"%num[number-number//10*10])
        else:
            print(" ")
    elif number>0:
        print("%c"%num[number],end=' ')
    else:
        print("영원")
        
