#2-6
ftword="apple"
score=0
word=[]
for i in range(10):
    print("단어(%s):"%ftword,end='')
    scword=input()
    if len(scword)<3 or len(scword)>6:
        score -=1
        print("글자수가 맞지 않습니다. 다시 입력하세요. 현재점수 %d점"%score)
        continue
    if ftword[-1]==scword[0]:
        if scword in word:
            score -=1
            print("이미 나온 단어입니다. 1점 차감. 현재점수 %d점" %score)
        else:
            score +=1
            word.append(scword)
            ftword=scword
            print("1점 획득.현재점수 %d점" %score)
    elif ftword[-1]!=scword[0]:
        score -=1
        print("끝말잇기가 안됩니다. 1점 차감. 현재점수 %d점" %score)
