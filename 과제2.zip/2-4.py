#2-4
telephone={"홍길동":"010-4444-5555","김중앙":"010-9191-8181","심청":"010-3232-5454"}
while True:
    yes=0
    name=input("이름>>")
    a=list(telephone.keys())
    for i in range(len(a)):
         if name in a[i]:
             print("%s %s"%(a[i],telephone[a[i]]))
             yes +=1
    if yes>=1:
        continue
    else:
        if name=="add":
            nameadd=input("이름은?")
            teleadd=input("전화번호는?")
            telephone[nameadd]=teleadd
            print("%s 전화번호가 추가되었습니다"%nameadd)
        elif name in telephone.keys():
            print("%s %s"%(name,telephone[name]))
        else:
            print("찾을 수 없습니다.")
    
            
        


