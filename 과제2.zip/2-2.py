#2-2
while True:
    introduce=input("문장을 입력하세요:")
    first=list(introduce.split("."))
    name=list(first[0].split(" "))
    if name[0]=="저는":
        if len(name)==2:
            if name[1][-3:]=="입니다":
                print("이름:%s"%name[1][0:-3])
            else:
                continue
        if len(name)==3:
            if name[2]=="합니다":
                print("이름:%s"%name[1][0:-3])
            else:
                continue
    if name[0]=="제":
        if len(name)==3:
            if name[2][-3:]=="입니다":
                print("이름:%s"%name[2][0:-3])
            else:
                continue
                    
            
                
    
