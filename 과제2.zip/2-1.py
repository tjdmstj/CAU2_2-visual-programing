#2-1
import random
cw=pw=cl=pl=0
rround=1
RSP=("가위","바위","보")

while True:
    print("(라운드%d)"%rround)
    rround +=1
    com=random.randint(1,3)
    user=input("가위,바위,보?")
    if user==RSP[0]:
        user=1
    elif user==RSP[1]:
        user=2
    else:
        user=3
    if(user==com):
        print("비겼습니다.")
        continue
    elif com<user:
        if com==1 and user==3:
            cw=cw+1
            pl=pl+1
            print("컴퓨터는 가위, 당신은 보, 컴퓨터가 이겼습니다.")
        else:
            cl=cl+1
            pw=pw+1
            if com==1 and user==2:
                print("컴퓨터는 가위, 당신은 바위, 당신이 이겼습니다.")
            else:
                print("컴퓨터는 바위, 당신은 보, 당신이 이겼습니다.")
    else:
        if com==3 and user==1:
            cl=cl+1
            pw=pw+1
            print("컴퓨터는 보, 당신은 가위, 당신이 이겼습니다.")
        else:
            cw=cw+1
            pl=pl+1
            if com==2 and user==1:
                print("컴퓨터는 바위, 당신은 가위, 컴퓨터가 이겼습니다.")
            else:
                print("컴퓨터는 보, 당신은 바위, 컴퓨터가 이겼습니다.")
    if cw==3 or pw==3:
        print("컴퓨터",cw,"승",cl,"패",end=' ')
        print("당신",pw,"승",pl,"패")
        break
    
