#2-3
while True:
    susik=input("수식을 입력하세요(단, 덧셈과 뺄셈만 가능)")
    if "+" in susik:
        a=list(susik.split("+"))
        for i in range(0,len(a)):
            if "-" in a[i]:
                a[i]=list(a[i].split("-"))
                for j in range(len(a[i])-1):
                    a[i][j+1]=int(a[i][j])-int(a[i][j+1])
                a[i]=a[i][len(a[i])-1]
    for i in range(len(a)):
        if type(a[i])==str:
            a[i]=int(a[i])
    print(sum(a))

            
